setwd("C:\\Users\\it24101104\\Desktop\\IT24101104")

data<-read.table("Data.txt",header=TRUE,sep=",")
fix(data)

names(data)<-c("x1","x2")
fix(data)

attach(data)

x1
x2

hist(x2,main="Histogram of x2")
summary(x2)

histogram<-hist(x2,main="Histogram of x2",
     breaks=seq(130,270,length=8))
histogram

breaks<-round(histogram$breaks)
breaks

freq<-histogram$counts
freq

mid<-histogram$mids
mid

class<-c()

for(i in 1:length(breaks)-1){
  class[i]<-paste0("{",breaks[i],",",breaks[i+1],"}")
}
class  

cbind(classes=class,frequency=freq)

lines(mid,freq)

plot(mid,freq,type="0",
     main="freq polygon for no of shareholders",
     ylab="frequency",xlab="shareholder",
     ylim=c(0,max(freq)))

cum.freq<-cumsum(freq)
cum.freq

new<-c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

new
plot(breaks,new,type="o",
     main="freq polygon for no of shareholders",
     ylab="cummulative frequency",xlab="shareholder",
     ylim=c(0,max(cum.freq)))
