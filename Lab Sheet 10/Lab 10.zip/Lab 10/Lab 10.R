setwd("C:\\Users\\IT24101104\\Desktop\\Lab 10")
snacks <- c(25, 30, 20, 25)
result3 <- chisq.test(snacks, p = rep(1/4, 4))
result3
