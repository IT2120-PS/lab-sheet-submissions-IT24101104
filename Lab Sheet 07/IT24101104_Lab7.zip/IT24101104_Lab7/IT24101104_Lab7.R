setwd("C:\\Users\\user\\OneDrive\\Desktop\\IT24101104_Lab7")

# 1).
cat("Problem 1: Uniform Distribution - Train Arrival Time\n")
cat("X~Uniform(0,40)minutes\n")

prob1<-punif(25,min=0,max=40) -punif(10,min=0,max=40)
cat("Probability train arrives between 8:10 and 8:25 am:",round(prob1,4),"\n")
cat("or as function:",(25-10)/40,"\n\n")



# 2).
cat("Problem 2:Expotential Distribution - Software Update Time\n")
cat("X~Expotential(λ=1/3)\n")

prob2<-pexp(2,rate=1/3)
cat("Probability update takes at most 2 hours:",round(prob2,4),"\n\n")



# 3).
cat("Problem 3: Normal Distribution - IQ Scores\n")
cat("X ~ Normal(μ = 100, σ = 15)\n")

# part 1:
prob3_1 <- 1 - pnorm(130, mean = 100, sd = 15)
cat("1. Probability IQ > 130:", round(prob3_1, 4), "\n")

# part2:
iq_95 <- qnorm(0.95, mean = 100, sd = 15)
cat("2. 95th percentile IQ score:", round(iq_95, 2), "\n")

cat("Verification - P(X <", round(iq_95, 2), ") =", 
    round(pnorm(iq_95, mean = 100, sd = 15), 4), "\n")
